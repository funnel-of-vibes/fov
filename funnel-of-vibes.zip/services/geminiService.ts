import { GoogleGenAI, Type } from "@google/genai";
import { VibeAnalysisResult } from "../types";

const processVibeCheck = async (name: string, description: string): Promise<VibeAnalysisResult> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("No API Key found. Returning mock data.");
    return {
      vibeScore: Math.floor(Math.random() * 30) + 50,
      shortDescription: "Standard analysis unavailable. Running simulation."
    };
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Analyze the following webapp idea and give it a 'vibe score' (0-100) based on its potential popularity and coolness. Also write a short, professional but engaging description (max 20 words) for it.
      
      App Name: ${name}
      App Description: ${description}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            vibeScore: { type: Type.INTEGER, description: "A score from 0 to 100." },
            shortDescription: { type: Type.STRING, description: "A short, engaging description." }
          },
          required: ["vibeScore", "shortDescription"]
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) throw new Error("No text returned from Gemini");

    const result = JSON.parse(jsonText) as VibeAnalysisResult;
    return result;

  } catch (error) {
    console.error("Gemini Vibe Check failed:", error);
    return {
      vibeScore: Math.floor(Math.random() * 100),
      shortDescription: "Analysis failed. Please try again."
    };
  }
};

export { processVibeCheck };